import db from "../../config/db.js";

// Get category

export const getCotegoriesForApi = (req, res) => {
  const sql = "SELECT * FROM blog_category";

  db.query(sql, (err, result) => {
    if (err) {
      return res.status(500).send("Database Error: " + err.message);
    }

    return res.status(202).json({
      message: "category get successfull",
      result,
    });
  });
};

// get CareerJobs

export const getCareerJobs = (req, res) => {
  const sql = "SELECT * FROM career_jobs ORDER BY id DESC";

  db.query(sql, (err, jobs) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: "Database Error",
        error: err,
      });
    }
    res.status(200).json({
      success: true,
      message: "Career jobs fetched successfully",
      data: jobs,
    });
  });
};

//  Get BLOG LIST WITH CATEGORY NAME

export const getBlogsWithCategory = (req, res) => {
  const sql = `
    SELECT 
      blogs.id,
      blogs.title,
      blogs.slug,
      blogs.status,
      blogs.image,
      blogs.created_at,
      blogs.short_description,
      blogs.content,
      blogs.category_id,
      blog_category.category_name
    FROM blogs
    LEFT JOIN blog_category 
      ON blogs.category_id = blog_category.category_id
    ORDER BY blogs.id DESC
  `;

  db.query(sql, (err, result) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: "Database error while fetching blogs",
        error: err.message,
      });
    }

    res.status(200).json({
      success: true,
      message: "Blogs fetched successfully",
      total: result.length,
      data: result,
    });
  });
};

// GET all employees
export const getEmployees = (req, res) => {
  const sql = "SELECT * FROM employees ORDER BY created_at DESC";

  db.query(sql, (err, result) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: "Database error while fetching employees",
        error: err.message,
      });
    }

    res.status(200).json({
      success: true,
      message: "Employees fetched successfully",
      total: result.length,
      data: result,
    });
  });
};




