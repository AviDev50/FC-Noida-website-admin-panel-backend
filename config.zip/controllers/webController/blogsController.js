import db from "../../config/db.js";
import slugify from "slugify";

// Create Blog
export const createBlog = (req, res) => {
  const { category_id, title, short_description, content, status } = req.body;
  const image = req.file ? req.file.filename : null;
  let { slug } = req.body;

  if (!slug || slug.trim() === "") {
    slug = slugify(title, { lower: true, strict: true });
  }

  const sql = `
    INSERT INTO blogs
    (category_id, title, slug, short_description, content, status, image)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [category_id, title, slug, short_description, content, status, image],
    (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Database Error: " + err.message);
      }

      res.redirect("/admin/blogs");
    }
  );
};

// Get all blogs
export const getBlogs = (req, res) => {
  const sql = "SELECT * FROM blogs";
  db.query(sql, (err, result) => {
    if (err) return res.status(500).send("Database Error: " + err.message);
    res.render("blogs", { title: "All Blogs", blogs: result});
  });
  console.log(result)
};

//delete blog

export const deleteBlogs = (req, res) => {
  const { id } = req.params;

  const sql = "DELETE FROM blogs WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({
        message: "Database error",
        error: err,
      });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Blog not found!",
      });
    }

    // return res.status(200).json({
    //   message: "Blog deleted successfully",

    // });
    res.redirect("/admin/blogs");
  });
};



// // Get blogs by category_id
// export const getBlogsByCategory = (req, res) => {
//   const categoryId = req.query.category_id;
//   let sql = `
//     SELECT blogs.id, blogs.title, blogs.slug, blogs.status,
//            blogs.short_description, blogs.content, blogs.image,
//            blog_category.category_name, blog_category.category_id
//     FROM blogs
//     LEFT JOIN blog_category 
//       ON blogs.category_id = blog_category.category_id
//   `;
//   const params = [];

//   if (categoryId) {
//     sql += " WHERE blogs.category_id = ?";
//     params.push(categoryId);
//   }

//   sql += " ORDER BY blogs.created_at DESC";

//   db.query(sql, params, (err, result) => {
//     if (err) return res.status(500).json(err);
//     res.json(result);
//   });
// };

// dropdown ke liye

export function showAddBlogForm(req, res) {
  const sql = "SELECT * FROM blog_category";

  db.query(sql, (err, categories) => {
    if (err) {
      return res.status(500).send("Database Error: " + err.message);
    }

    res.render("addBlogs", {
      title: "Add New Blog",
      categories, // dropdown ke liye
    });
  });
}

// ===============================
// BLOG LIST WITH CATEGORY NAME
// ===============================
export const getBlogsWithCategory = (req, res) => {
  const sql = `
    SELECT 
      blogs.id,
      blogs.title,
      blogs.slug,
      blogs.status,
      blogs.image,
      blogs.created_at,
      blogs.short_description,
      blogs.content,
      blogs.category_id,
      blog_category.category_name

    FROM blogs
    LEFT JOIN blog_category 
      ON blogs.category_id = blog_category.category_id
    ORDER BY blogs.id DESC
  `;

  db.query(sql, (err, result) => {
    if (err) return res.status(500).send(err.message);

    res.render("blogs", {
      blogs: result,
    });
  });
};





// show edit blog form

export const showEditBlogForm = (req, res) => {
  const blogId = req.params.id;

  //Blog data (with selected category)
  const blogSql = `SELECT blogs.*FROM blogs WHERE blogs.id = ?`;

  //All categories (for dropdown)
  const categorySql = `
    SELECT * FROM blog_category
  `;

  db.query(blogSql, [blogId], (err, blogResult) => {
    if (err) {
      console.log(err);
      return res.status(500).send("Database error (blog)");
    }

    if (!blogResult.length) {
      return res.status(404).send("Blog not found");
    }

    db.query(categorySql, (err, categoryResult) => {
      if (err) {
        console.log(err);
        return res.status(500).send("Database error (categories)");
      }
      res.render("editBlogForm", {
        blog: blogResult[0],
        categories: categoryResult
      });
    });
  });
};




// Update Blog
export const updateBlogs = (req, res) => {
  const { id } = req.params;

  const { title, slug, short_description, content, status, category_id } = req.body;


  const image = req.file ? req.file.filename : null;

  // Auto-generate slug if empty
  const finalSlug = slug && slug.trim() !== '' ? slug : slugify(title, { lower: true, strict: true });


  let sql = `
    UPDATE blogs 
    SET title = ?, slug = ?, short_description = ?, content = ?, status = ?, category_id = ?
  `;
  const params = [title, finalSlug, short_description, content, status, category_id];

  // Only update image if a new one is uploaded
  if (image) {
    sql += ', image = ?';
    params.push(image);
  }

  sql += ' WHERE id = ?';
  params.push(id);

  db.query(sql, params, (err, result) => {
    if (err) {
      console.error("Database Error:", err);
      return res.status(500).send("Something went wrong while updating the blog.");
    }

    // Redirect to blogs list after successful update
    res.redirect("/admin/blogs");
  });
};
