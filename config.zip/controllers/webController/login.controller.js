// ================= SHOW LOGIN =================
export const showLogin = (req, res) => {
  // 🔒 Agar already login hai to dobara login page mat dikhao
  if (req.session.admin) {
    return res.redirect("/admin/dashboard");
  }

  res.render("login", {
    title: "Admin Login",
    layout: false
  });
};

// ================= LOGIN ADMIN =================
export const loginAdmin = (req, res) => {
  const { email, password } = req.body;

  // ✅ Only admin allowed
  if (email === "admin@gmail.com" && password === "1234") {
    req.session.admin = true;   // session set
    return res.redirect("/admin/dashboard");
  }

  // ❌ Wrong credentials
  res.render("login", {
    title: "Admin Login",
    error: "Invalid admin credentials",
    layout: false
  });
};

// ================= LOGOUT ADMIN =================
export const logoutAdmin = (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.redirect("/login");
  });
};
