import express, { Router } from "express";
import db from "../../config/db.js";
import { getBlogsWithCategory, getCareerJobs, getCotegoriesForApi, getEmployees } from "../../controllers/apiController/fcapi.js";

const router = Router();

// get category
router.get("/Category", getCotegoriesForApi);

// get career

router.get("/career", getCareerJobs);

// get blogs

router.get("/blogs",getBlogsWithCategory);


//get employees

router.get("/employees", getEmployees);

export default router;
