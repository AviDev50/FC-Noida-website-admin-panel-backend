import express from "express";
import session from "express-session";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import authentication from "./middlewares/authentication.js";

import adminRoutes from "./routes/webRoutes/dashboard.routes.js";
import loginRoutes from "./routes/webRoutes/login.routes.js";
import blogsRoutes from "./routes/webRoutes/blogsRoutes.js";
import careerRoutes from "./routes/webRoutes/carrierRoutes.js";
import employeesRoutes from "./routes/webRoutes/employeesRoutes.js";
import enquiryRoutes from "./routes/webRoutes/equiryRoutes.js";
import categoryRoutes from "./routes/webRoutes/categoryRoutes.js";

import fcApiRoutes  from "./routes/apiRoutes/fcApiRoutes.js"



const app = express();
app.use(cors());

// dirname fix (ES module)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ---------------- VIEW ENGINE ----------------
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ---------------- BODY PARSER ----------------
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

//session

app.use(
  session({
    secret: "superAdminSecretKey",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 2, // 2 hours
    },
  })
);

app.use("/uploads", express.static(path.join(__dirname, "public/uploads")));

app.use(express.static(path.join(__dirname, "public")));





// =====================API Routes============================
app.use("/admin/api", fcApiRoutes);


// ---------------- ROUTES ----------------
app.use("/", loginRoutes);
app.use("/admin", adminRoutes);
app.use("/admin", blogsRoutes);
app.use("/admin", careerRoutes);
app.use("/admin", employeesRoutes);
app.use("/admin", enquiryRoutes);;
app.use("/admin", categoryRoutes);




// dashboard
app.get("/", authentication,(req, res) => {
  res.redirect("/admin/dashboard");
});

// ---------------- SERVER ----------------
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
